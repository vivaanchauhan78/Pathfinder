#include "arduino_secrets.h"

/*
 */
void setup() {
  int BUT1 = D0;
  
  int BUT2 = D1;
  
  int BUT3 = D2;
  
  
  int LED1 = D3;
  
  int LED2 = D4;
  
  int LED3 = D5;
  
    
  pinMode(BUT1, INPUT_PULLUP);
  
  pinMode(BUT2, INPUT_PULLUP);
  
  pinMode(BUT3, INPUT_PULLUP);
  
  
  pinMode(LED1, OUTPUT);
  
  pinMode(LED2, OUTPUT);
  
  pinMode(LED3, OUTPUT);
  
  
  long startTime = millis();

  

}

void loop() {

  long but1time;
  long but2time;
  
  long but3time = 0;
  if (digitalRead(BUT1) == HIGH) {
  
    but1time = millis(); 
    digitalWrite(LED1, HIGH);
  } 
  else {
  
    digitalWrite(LED1, LOW);
  }
  if (digitalRead (BUT2) == HIGH) {

  but2time = millis();
  }
  if (abs(but2time - but1time) <= 2000) {

    digitalWrite(LED2, HIGH);

  } 
  else {

    digitalWrite(LED2, LOW);
  } 
  if (digitalRead (BUT3) == HIGH) {

    but3time++;
  } 
  else {

    but3time = 0 ;
  }
  if (but3time >= 800 ) {

    digitalWrite (LED3, HIGH);
  } 
  else {

    digitalWrite (LED3, LOW);
  }
}

